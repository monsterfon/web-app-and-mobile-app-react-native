function Style(){
    //TEXT VARIABLES
    this.titleSize = 30;
    this.annotationSize = 15;
    this.hoverSize = 30;
    this.hoverSize2 = 14;
    this.numOfDataSize = 20;
    this.buttonSize = 17;

    this.textColor = '#bac2de'
    this.white = '#ffffff'
    this.backgroundColor = '#222232'
    this.dataColor = '#9399b2'
    this.blockColor = '#313244'
    this.blockColorLight = '#45475a'
    this.annotationLines = '#585b70'
    this.green = '#a4f28a'
    this.red = '#f38ba8'
    this.hoverColor = color(198, 208, 245, 70)
    this.unselectedColor = color(147, 153, 178, 170)
    this.selectionBarColor = '#f5e0dc'

//STYLE 1 
/*
    this.white = '#a4f28a'
    this.dataColor = '#f9e2af'
    this.green = '#a4f28a'
    this.red = '#a4f28a'
*/
  
  this.upadteTitleSize = function(text){
    this.titleSize = 30
    textSize(this.titleSize)
    let textW = textWidth(text)
    while(windowWidth-150 < textW){
      this.titleSize -= 1;
      if(this.titleSize <=1){
        this.titleSize = 1;
        break;
      }
      if (windowWidth-100 <= 0){
        this.titleSize = 1;
        break;
      }
      textSize(this.titleSize)
      textW = textWidth(text)
    }
  }
  
  this.getTitle = function(){
    return {'fontSize': this.titleSize, 'color': this.textColor, 'align':LEFT, 'alignY': BOTTOM, 'yOffset': 0}
  }
  this.getButton = function(){
    return {'fontSize': this.buttonSize, 'color': this.textColor, 'align':CENTER, 'alignY': CENTER, 'yOffset': 0}
  }
  this.getNumberOfDatapoints = function(){
    return {'fontSize': this.numOfDataSize, 'color': this.textColor, 'align':RIGHT, 'alignY': BOTTOM, 'yOffset': 0}
  }
  this.getAnnotation = function(){
    return {'fontSize': this.annotationSize, 'color': this.textColor, 'yOffset': 5}
  }
  this.getScaleAnnotation = function(){
    return {'fontSize': this.annotationSize, 'color': this.textColor, 'yOffset': 0, 'align':RIGHT, 'alignY': CENTER}
  }
  this.getBlockTitle = function(){
    return {'fontSize': this.annotationSize, 'color': this.textColor, 'align':LEFT, 'yOffset': -1*this.annotationSize}
  }
  this.getDataHoverPos = function(){
    return {'fontSize': this.hoverSize, 'color': this.white, 'border': 3, 'borderColor':this.backgroundColor, 'align':RIGHT, 'yOffset': -0.8*this.hoverSize2-this.hoverSize}
  }
  this.getDataHoverNeg = function(){
    return {'fontSize': this.hoverSize, 'color': this.textColor, 'border': 3, 'borderColor':this.backgroundColor, 'align':RIGHT, 'yOffset': -0.8*this.hoverSize2-this.hoverSize}
  }
  this.getDataHover2 = function(){
    return {'fontSize': this.hoverSize2, 'color': this.textColor, 'border': 3, 'borderColor':this.backgroundColor, 'align':RIGHT, 'yOffset': -0.8*this.hoverSize2}
  }
  this.getBlockStyle = function(){
    return {'backgroundColor': this.blockColor = '#313244','color': this.textColor, 'scaleAnnotation': this.getScaleAnnotation(), 'text': this.getBlockTitle()}
  }
  this.getLightBlockStyle = function(){
    return {'backgroundColor': this.blockColor = '#45475a','color': this.textColor, 'scaleAnnotation': this.getScaleAnnotation(), 'text': this.getBlockTitle()}
  }
}
